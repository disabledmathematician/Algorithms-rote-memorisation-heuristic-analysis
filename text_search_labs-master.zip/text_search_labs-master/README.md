# text_search_labs

- lab1:
Naive string-search algorithm

- lab2:
Rabin–Karp algorithm

- lab3:
Finite state automaton based algorithm

- lab4:
Knuth–Morris–Pratt algorithm

- lab5:
Boyer–Moore string-search algorithm

_____
__Requirements__
 - python 3
 - pytest
 - inject
 